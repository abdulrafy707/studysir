module.exports = {
  images: {
    domains: ['localhost', 'studysir.m3xtrader.com'],
  },
};
