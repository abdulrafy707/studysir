'use client'
import AdminUsers from "./AddAdminUser";
export default function Blogs() {
  return (
    <>
      <AdminUsers/>
    </>
  );
}
