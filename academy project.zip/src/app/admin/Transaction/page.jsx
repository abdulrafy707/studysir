import React from "react";



import Transactions from "./Transaction";

const Page = () => {
  return (
    <div>
      {/* <h1> Game Transaction Managment</h1> */}
      {/* <TransactionComponent /> */}
      <Transactions/>
      
      
    </div>
  );
};

export default Page;
