import React from "react";


import TransactionComponent from "./TransactionComponent";

const Page = () => {
  return (
    <div>
      {/* <h1> Game Transaction Managment</h1> */}
      <TransactionComponent />
      
      
    </div>
  );
};

export default Page;
