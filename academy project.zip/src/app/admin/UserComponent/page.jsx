import React from "react";

import UserComponent from "./UserComponent";

const Page = () => {
  return (
    <div>
    
      <UserComponent/>
      
      
    </div>
  );
};

export default Page;
