'use client';
import { useState, useEffect } from 'react';
import { FaStar } from 'react-icons/fa';

export default function EbookCard({ ebook }) {
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [showReviewSection, setShowReviewSection] = useState(false);
  const [newReview, setNewReview] = useState('');
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(null);
  const [likes, setLikes] = useState(ebook.likes || 0);
  const [isLiked, setIsLiked] = useState(false);
  const [showDownloadConfirm, setShowDownloadConfirm] = useState(false);
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const checkIfLiked = async (ebookId) => {
      const userData = JSON.parse(localStorage.getItem('user'));
      if (!userData || !userData.id) return;
      const postData = {
        username: userData.username,
        post_id: ebookId,
        post_type: 'ebookpost',
      };
      try {
        const response = await fetch(`${baseUrl}/check_like_api.php`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(postData),
        });
        const result = await response.json();
        if (result.liked) setIsLiked(true);
      } catch (error) {
        console.error('Error checking like status:', error);
      }
    };
    checkIfLiked(ebook.id);
  }, [ebook.id]);

  const handleLikePost = async (ebookId) => {
    const userData = JSON.parse(localStorage.getItem('user'));
    if (!userData || !userData.id) {
      alert('User not logged in');
      return;
    }
    const postData = {
      username: userData.username,
      post_id: ebookId,
      post_type: 'ebookpost',
    };
    try {
      const response = await fetch(`${baseUrl}/like_api.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
      });
      const result = await response.json();
      if (result.liked) {
        setLikes(result.total_likes);
        setIsLiked(true);
      } else {
        alert(`Error liking post: ${result.error}`);
      }
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const fetchReviews = async (ebookId) => {
    try {
      const response = await fetch(`${baseUrl}/ebook_review_api.php?ebook_id=${ebookId}`);
      const data = await response.json();
      if (Array.isArray(data)) setReviews(data);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const toggleReviewSection = (ebookId) => {
    setShowReviewSection(!showReviewSection);
    if (!showReviewSection) fetchReviews(ebookId);
  };

  const handleReviewSubmit = async (ebookId) => {
    const userData = JSON.parse(localStorage.getItem('user'));
    if (!userData || !userData.id) {
      alert('User not logged in');
      return;
    }
    if (rating === 0) {
      alert('Please give a star rating');
      return;
    }
    const payload = {
      ebook_id: ebookId,
      user_id: userData.id,
      comment: newReview,
      rating,
    };
    try {
      const response = await fetch(`${baseUrl}/ebook_review_api.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (result.success) {
        alert('Review submitted successfully');
        setNewReview('');
        setRating(0);
        fetchReviews(ebookId);
      } else {
        alert(`Error submitting review: ${result.error}`);
      }
    } catch (error) {
      console.error('Error submitting review:', error);
    }
  };

  const getTruncatedDescription = (description) => {
    const words = description.split(' ');
    return words.length > 30 ? words.slice(0, 30).join(' ') : description;
  };

  return (
    <div className="bg-white border rounded-lg shadow-lg p-4 w-[300px] md:w-[600px] mx-auto my-6">
      <div className="flex flex-col md:flex-row justify-between space-x-4">
        <div className="w-full md:w-1/3 flex flex-col justify-between">
          <img
            src={`${baseUrl}/uploads/${ebook.cover_page_image_url}`}
            alt={ebook.ebook_title || 'Ebook Image'}
            className="rounded-lg object-cover w-full h-40 mb-2"
          />
          <p className="text-gray-800 font-bold text-base">Rs {ebook.price || 'N/A'}</p>
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-gray-900 mb-1">{ebook.ebook_title || 'Ebook Title'}</h2>
          <p className="text-gray-600 text-sm mb-2">Written by {ebook.author_name || 'Author'}</p>

          <p className="text-gray-700 text-xs leading-relaxed mb-2">
            {showFullDescription
              ? ebook.description || 'No description available.'
              : getTruncatedDescription(ebook.description || 'No description available.')}
            {ebook.description && ebook.description.split(' ').length > 30 && (
              <span
                className="text-blue-500 cursor-pointer ml-2"
                onClick={() => setShowFullDescription(!showFullDescription)}
              >
                {showFullDescription ? 'See Less' : 'See More'}
              </span>
            )}
          </p>

          <p className="text-gray-800 font-semibold text-sm">
            Seller: <span className="text-gray-500">{ebook.seller_name || 'Seller Name'}</span>
          </p>
        </div>
      </div>

      <div className="mt-4 flex justify-between items-center border-t pt-2">
        <div className="flex space-x-6">
          <button
            className={`flex items-center ${isLiked ? 'text-blue-600' : 'text-gray-500'} hover:text-blue-600`}
            onClick={() => handleLikePost(ebook.id)}
          >
            <img src="/like.png" alt="Like Icon" width={16} height={16} />
            <span className="ml-2 text-sm">{likes}</span>
          </button>
          <button className="flex items-center text-gray-500 hover:text-blue-600" onClick={() => toggleReviewSection(ebook.id)}>
            <img src="/review1.png" alt="Review Icon" width={16} height={16} />
            <span className="ml-2 text-sm">{reviews.length || 0}</span>
          </button>
          <button className="flex items-center text-gray-500 hover:text-blue-600">
            <img src="/share.png" alt="Share Icon" width={16} height={16} />
            <span className="ml-2 text-sm">{ebook.shares || 0}</span>
          </button>
        </div>
        <button
          className="flex items-center text-gray-500 hover:text-blue-600"
          onClick={() => setShowDownloadConfirm(true)}
        >
          <img src="/download.png" alt="Download Icon" width={16} height={16} />
          <span className="ml-2 text-sm">{ebook.downloads || 'Download'}</span>
        </button>
      </div>

      {showReviewSection && (
        <div className="mt-4 border-t pt-4">
          <h3 className="font-bold text-lg text-gray-800 mb-2">User Reviews</h3>

          <div className="space-y-2">
            {reviews.length > 0 ? (
              reviews.map((review) => (
                <div key={review.id} className="p-2 bg-gray-100 rounded-lg shadow-sm">
                  <p className="font-semibold text-blue-600 text-sm">{review.fullname}</p>
                  <p className="text-gray-700 text-xs mt-1">{review.comment}</p>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <FaStar key={i} size={12} className="text-yellow-500" />
                      ))}
                    </div>
                    <span className="ml-2 text-gray-500 text-xs">{new Date(review.created_at).toLocaleString()}</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-xs">No reviews yet. Be the first to review!</p>
            )}
          </div>

          <div className="mt-6">
            <h4 className="font-semibold text-sm text-gray-800 mb-2">Leave a Review</h4>
            <textarea
              value={newReview}
              onChange={(e) => setNewReview(e.target.value)}
              placeholder="Write your review here..."
              className="w-full p-2 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-300 text-xs"
            />
            <div className="flex items-center space-x-1 mt-2">
              {[...Array(5)].map((_, index) => {
                const ratingValue = index + 1;
                return (
                  <FaStar
                    key={ratingValue}
                    size={20}
                    className={`cursor-pointer ${ratingValue <= (hoverRating || rating) ? 'text-yellow-500' : 'text-gray-300'}`}
                    onClick={() => setRating(ratingValue)}
                    onMouseEnter={() => setHoverRating(ratingValue)}
                    onMouseLeave={() => setHoverRating(null)}
                  />
                );
              })}
            </div>
            <button
              onClick={() => handleReviewSubmit(ebook.id)}
              className="mt-3 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-all duration-200 text-xs"
            >
              Submit Review
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
