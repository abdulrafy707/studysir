'use client';
import { useState, useEffect } from 'react';
import { FaLanguage, FaChalkboardTeacher, FaMale, FaRegClock, FaWallet } from 'react-icons/fa';
import { AiOutlineLike } from 'react-icons/ai';
import { BsFillChatDotsFill, BsThreeDots } from 'react-icons/bs';
import { MdLocationOn } from 'react-icons/md';
import { BiShare } from 'react-icons/bi';

export default function JobCard({ post }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [likes, setLikes] = useState(0);
  const [showChatPopup, setShowChatPopup] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [deductionMessage, setDeductionMessage] = useState('');
  const [coinsToDeduct, setCoinsToDeduct] = useState(0); // Calculate coins to deduct
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    if (post.likes) {
      setLikes(post.likes);
    }
  }, [post.likes]);

  const handleSavePost = async () => {
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !userData.id) {
      console.error('User not logged in');
      return;
    }

    const postData = {
      user_id: userData.id,
      post_id: post.post_id,
      post_type: 'studentpost',
    };

    try {
      const response = await fetch(`${baseUrl}/save_post_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });

      const result = await response.json();
      if (result.success) {
        alert('Post saved successfully!');
        setDropdownOpen(false); // Close the dropdown after saving
      } else {
        alert(`Error saving post: ${result.error}`);
      }
    } catch (error) {
      console.error('Error saving post:', error);
    }
  };

  const handleLikePost = async () => {
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !userData.id) {
      console.error('User not logged in');
      return;
    }

    const postData = {
      username: userData.username,
      post_id: post.post_id,
      post_type: 'studentpost',
    };

    try {
      const response = await fetch(`${baseUrl}/like_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });

      const result = await response.json();
      if (result.liked) {
        setLikes(result.total_likes);
      } else {
        alert(`Error liking post: ${result.error}`);
      }
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const handleLiveChatClick = () => {
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !userData.id) {
      console.error('User not logged in');
      return;
    }

    if (userData.role === 'student') {
      setErrorMessage('Students are not allowed to chat with this person.');
      return;
    }

    if (userData.role === 'teacher') {
      const feeBudget = post.fee_budget ? parseFloat(post.fee_budget) : 0;
      const coins = feeBudget < 5 ? 50 : feeBudget * 10;
      setCoinsToDeduct(coins);
      setShowChatPopup(true);
    }
  };

  const confirmChat = async () => {
    setShowChatPopup(false);
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !userData.id) {
      console.error('User not logged in');
      return;
    }

    const postData = {
      teacher_id: userData.id,
      post_id: post.post_id,
    };

    try {
      const response = await fetch(`${baseUrl}/coin_deduct_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });

      const result = await response.json();
      if (result.success) {
        setDeductionMessage(`Coins deducted successfully. Remaining coins: ${result.remaining_coins}`);
      } else {
        setDeductionMessage(`Error: ${result.error}`);
      }
    } catch (error) {
      console.error('Error deducting coins:', error);
      setDeductionMessage('Failed to deduct coins.');
    }
  };

  const closePopup = () => {
    setShowChatPopup(false);
  };

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  const getTruncatedDescription = (description) => {
    const words = description.split(' ');
    return words.length > 100 ? words.slice(0, 100).join(' ') : description;
  };

  return (
    <div className="bg-white border rounded-lg w-[300px] sm:w-[500px] md:w-[600px] shadow-lg p-4 my-8 relative mx-auto">
      {/* Header with student profile, name, and location */}
      <div className="flex items-start justify-between">
        <div className="flex items-center">
          <img
            src={post.profile_image ? `${baseUrl}/uploads/${post.profile_image}` : '/default-profile.png'}
            alt="Profile Picture"
            className="rounded-full w-10 h-10 sm:w-12 sm:h-12"
          />
          <div className="ml-2 sm:ml-4">
            <h2 className="text-xs sm:text-sm font-bold">{post.name || 'Student'}</h2>
            <p className="text-gray-500 text-xs sm:text-sm flex items-center">
              <MdLocationOn className="mr-1" />
              {post.location || 'Location not provided'}
            </p>
          </div>
        </div>
        <div className="flex flex-col items-start space-y-2">
          <BsThreeDots
            className="cursor-pointer text-gray-600 hover:text-gray-800 ml-2 text-xs sm:text-sm"
            onClick={toggleDropdown}
          />
          {dropdownOpen && (
            <div className="absolute right-0 top-8 bg-white shadow-lg rounded-lg w-32">
              <ul className="py-2">
                <li
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 cursor-pointer"
                  onClick={handleSavePost}
                >
                  Save Post
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Job Title and Description */}
      <h3 className="mt-4 text-xs sm:text-sm font-bold">{post.job_title || 'Job Title not available'}</h3>
      <p className="text-gray-700 text-xs sm:text-sm mt-2">
        {showFullDescription
          ? post.job_description || 'Job description not provided'
          : getTruncatedDescription(post.job_description || 'Job description not provided')}{' '}
        {post.job_description && post.job_description.split(' ').length > 100 && (
          <span className="text-blue-500 cursor-pointer" onClick={toggleDescription}>
            {showFullDescription ? 'See Less' : 'See More'}
          </span>
        )}
      </p>

      {/* Job details with icons */}
      <div className="mt-4 space-y-2">
        <div className="flex items-center space-x-2">
          <FaLanguage className="text-gray-700 text-xs sm:text-sm" />
          <p className="font-bold text-xs sm:text-sm">Languages:</p>
          <p className="text-xs sm:text-sm">{Array.isArray(post.languages) && post.languages.length > 0 ? post.languages.join(', ') : 'Not specified'}</p>
        </div>

        <div className="flex items-center space-x-2">
          <FaChalkboardTeacher className="text-gray-700 text-xs sm:text-sm" />
          <p className="font-bold text-xs sm:text-sm">Subjects:</p>
          <p className="text-xs sm:text-sm">{Array.isArray(post.subjects) && post.subjects.length > 0 ? post.subjects.join(', ') : 'Not specified'}</p>
        </div>

        <div className="flex items-center space-x-2">
          <FaMale className="text-gray-700 text-xs sm:text-sm" />
          <p className="font-bold text-xs sm:text-sm">Required Gender:</p>
          <p className="text-xs sm:text-sm">{post.required_gender || 'Not specified'}</p>
        </div>

        <div className="flex items-center space-x-2">
          <FaRegClock className="text-gray-700 text-xs sm:text-sm" />
          <p className="font-bold text-xs sm:text-sm">Time Availability:</p>
          <p className="text-xs sm:text-sm">{post.time_availability || 'Not specified'}</p>
        </div>

        <div className="flex items-center space-x-2">
          <FaWallet className="text-gray-700 text-xs sm:text-sm" />
          <p className="font-bold text-xs sm:text-sm">Fee Budget:</p>
          <p className="text-xs sm:text-sm">{post.fee_budget ? `${post.fee_budget}$` : 'Not specified'}</p>
        </div>
      </div>

      {/* Action Buttons: Like, Share, and Live Chat */}
      <hr className="mt-4" />
      <div className="mt-2 flex justify-between items-center">
        <div className="flex space-x-4">
          <button className="flex items-center text-gray-500 hover:text-blue-500" onClick={handleLikePost}>
            <AiOutlineLike className="mr-1 text-xs sm:text-sm" />
            <span className="text-xs sm:text-sm">{likes} Like{likes === 1 ? '' : 's'}</span>
          </button>
          <button className="flex items-center text-gray-500 hover:text-blue-500">
            <BiShare className="mr-1 text-xs sm:text-sm" />
            <span className="text-xs sm:text-sm">Share</span>
          </button>
        </div>
        <button className="flex items-center text-gray-500 hover:text-blue-500" onClick={handleLiveChatClick}>
          <BsFillChatDotsFill className="mr-1 text-xs sm:text-sm" />
          <span className="text-xs sm:text-sm">Live Chat</span>
        </button>
      </div>

      {/* Chat Popup */}
      {showChatPopup && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-sm sm:w-[400px]">
            <h2 className="text-xs sm:text-lg font-bold text-gray-800 mb-4">Confirm Chat</h2>
            <p className="text-gray-600 mb-6 text-xs sm:text-sm">
              You are about to start a chat with this person. This will deduct <strong>{coinsToDeduct} coins</strong> from your account.
            </p>
            <div className="flex justify-end">
              <button className="bg-red-500 text-white px-4 py-2 rounded mr-4 text-xs sm:text-sm" onClick={closePopup}>
                Cancel
              </button>
              <button className="bg-blue-500 text-white px-4 py-2 rounded text-xs sm:text-sm" onClick={confirmChat}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error and Deduction Messages */}
      {errorMessage && <div className="text-red-500 mt-4 text-xs sm:text-sm">{errorMessage}</div>}
      {deductionMessage && <div className="text-green-500 mt-4 text-xs sm:text-sm">{deductionMessage}</div>}
    </div>
  );
}
