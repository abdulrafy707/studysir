'use client';
import { useState, useEffect } from 'react';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState(null);
  const [actionType, setActionType] = useState('');
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const fetchNotifications = async () => {
      const userData = JSON.parse(localStorage.getItem('user'));

      if (!userData || !userData.id) {
        console.error('User not logged in');
        return;
      }

      try {
        const response = await fetch(`${baseUrl}/fetch_notifications.php?user_id=${userData.id}`);
        const result = await response.json();

        if (result.success) {
          setNotifications(result.notifications);
        } else {
          console.error(result.message);
        }
      } catch (error) {
        console.error('Error fetching notifications:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, [baseUrl]);

  const handleAction = async () => {
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !selectedNotification || !actionType) return;

    const postData = {
      teacher_id: userData.id,
      student_id: selectedNotification.student_id,
      notification_id: selectedNotification.notification_id,
      amount: actionType === 'accept' ? 150 : 0,
      action: actionType
    };

    try {
      const response = await fetch(`${baseUrl}/handle_accept_reject_request.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
      });

      const result = await response.json();
      if (result.success) {
        alert(`${actionType.charAt(0).toUpperCase() + actionType.slice(1)}ed successfully!`);
        setNotifications((prevNotifications) =>
          prevNotifications.filter((n) => n.notification_id !== selectedNotification.notification_id)
        );
      } else {
        alert(`Error: ${result.error}`);
      }
    } catch (error) {
      console.error(`Error performing ${actionType}:`, error);
    } finally {
      setShowPopup(false);
    }
  };

  const handleActionClick = (notification, action) => {
    setSelectedNotification(notification);
    setActionType(action);
    setShowPopup(true);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto mt-8">
      
      {notifications.length > 0 ? (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div key={notification.notification_id} className="bg-white p-4 rounded-lg shadow-lg flex justify-between items-center">
              <div className="text-gray-800">
                <p>{notification.notification_message}</p>
                <p className="text-sm text-gray-500">{new Date(notification.created_at).toLocaleString()}</p>
              </div>
              <div className="flex items-center space-x-4">
                {!notification.is_read && (
                  <span className="px-3 py-1 bg-blue-500 text-white text-sm rounded-full">New</span>
                )}
                <button
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600"
                  onClick={() => handleActionClick(notification, 'accept')}
                >
                  Accept
                </button>
                <button
                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                  onClick={() => handleActionClick(notification, 'reject')}
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center mt-8">
          <img src="/nonotification.png" alt="No Notifications" className="w-64 h-64" />
          <p className="text-gray-500 mt-4">No notifications available.</p>
        </div>
      )}

      {showPopup && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 className="text-xl font-bold mb-4">Confirm Action</h2>
            <p>Are you sure you want to {actionType} this request?</p>
            {actionType === 'accept' && <p>150 coins will be deducted from your account.</p>}
            <div className="mt-4 flex justify-end space-x-4">
              <button
                className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                onClick={() => setShowPopup(false)}
              >
                Cancel
              </button>
              <button
                className={`bg-${actionType === 'accept' ? 'green' : 'red'}-500 text-white px-4 py-2 rounded-lg hover:bg-${actionType === 'accept' ? 'green' : 'red'}-600`}
                onClick={handleAction}
              >
                {actionType === 'accept' ? 'Accept' : 'Reject'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
