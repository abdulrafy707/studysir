'use client';
import { useEffect, useState } from 'react';
import { FaLanguage, FaCalendarAlt, FaChalkboardTeacher, FaDollarSign, FaClock, FaRegThumbsUp, FaUserFriends, FaEllipsisV } from 'react-icons/fa';
import { AiOutlineFileText } from 'react-icons/ai';
import { BiUser } from 'react-icons/bi';

export default function SavedPostsPage() {
  const [savedPosts, setSavedPosts] = useState([]);
  const [teachers, setTeachers] = useState({});
  const [dropdownOpen, setDropdownOpen] = useState(null);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [likes, setLikes] = useState(0);
  const [isJoinRequestOpen, setIsJoinRequestOpen] = useState(false);
  const [joinRequestMessage, setJoinRequestMessage] = useState('');
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const fetchSavedPosts = async () => {
      const userData = JSON.parse(localStorage.getItem('user'));
      if (userData && userData.id) {
        const response = await fetch(`${baseUrl}/save_post_api.php?user_id=${userData.id}`);
        const data = await response.json();
        setSavedPosts(data);
        data.forEach((post) => post.post_type === 'course' && fetchTeacherInfo(post.teacher_id));
      }
    };

    const fetchTeacherInfo = async (teacherId) => {
      const response = await fetch(`${baseUrl}/teacher_name_api.php?id=${teacherId}`);
      const teacherData = await response.json();
      setTeachers((prev) => ({ ...prev, [teacherId]: teacherData }));
    };

    fetchSavedPosts();
  }, [baseUrl]);

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);
  const toggleDescription = () => setShowFullDescription(!showFullDescription);
  const handleOpenJoinRequestPopup = () => setIsJoinRequestOpen(true);
  const handleCloseJoinRequestPopup = () => {
    setIsJoinRequestOpen(false);
    setJoinRequestMessage('');
  };

  const handleLikeCourse = async (post) => {
    const userData = JSON.parse(localStorage.getItem('user'));
    if (userData && userData.id) {
      const response = await fetch(`${baseUrl}/like_api.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userData.username, post_id: post.course_id, post_type: 'course' }),
      });
      const result = await response.json();
      result.liked && setLikes(result.total_likes);
    }
  };

  const handleSaveCourse = () => setDropdownOpen(false);

  const handleJoinRequest = async (post) => {
    const userData = JSON.parse(localStorage.getItem('user'));
    if (userData && userData.id) {
      const response = await fetch(`${baseUrl}/notifications_api.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: userData.id,
          teacher_id: post.teacher_id,
          amount: 150,
          course_title: post.course_title,
          fullname: userData.fullname,
          role: userData.role,
          message: joinRequestMessage,
        }),
      });
      const result = await response.json();
      result.success && alert('Join request sent to the teacher.');
      handleCloseJoinRequestPopup();
    }
  };

  return (
    <div>
      {savedPosts.map((post, index) => (
        <div key={index} className="bg-white border rounded-lg w-[300px] sm:w-[300px] md:w-[600px] shadow-lg p-4 my-8 relative mx-auto">
          {/* Join Request Popup */}
          {isJoinRequestOpen && (
            <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
              <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                <h2 className="text-xl font-bold mb-4">Send Join Request</h2>
                <textarea
                  value={joinRequestMessage}
                  onChange={(e) => setJoinRequestMessage(e.target.value)}
                  placeholder="Write a message to the teacher"
                  className="w-full border rounded-md p-2 mb-4"
                  rows="4"
                />
                <div className="flex justify-end space-x-2">
                  <button onClick={handleCloseJoinRequestPopup} className="bg-gray-400 text-white py-2 px-4 rounded-md hover:bg-gray-500">
                    Cancel
                  </button>
                  <button onClick={() => handleJoinRequest(post)} className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600">
                    Send Request
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Dropdown menu */}
          <div className="absolute top-4 right-4 flex justify-end">
            <FaEllipsisV className="cursor-pointer" onClick={toggleDropdown} />
            {dropdownOpen && (
              <div className="absolute right-0 bg-white shadow-md rounded-lg py-2">
                <button onClick={handleSaveCourse} className="block px-4 py-2 text-gray-700 hover:bg-gray-100 w-full text-left">
                  Save Course
                </button>
              </div>
            )}
          </div>

          {/* Teacher Info */}
          {/* {teachers[post.teacher_id] && (
            <div className="flex items-center mb-4 justify-between">
              <div className="flex">
                <img
                  src={teachers[post.teacher_id].image ? `${baseUrl}/uploads/${teachers[post.teacher_id].image}` : '/default-profile.png'}
                  alt={teachers[post.teacher_id].fullname || 'Profile Picture'}
                  className="rounded-full object-cover w-12 h-12 sm:w-16 sm:h-16"
                />
                <div className="ml-4">
                  <h2 className="text-sm sm:text-lg font-bold">{teachers[post.teacher_id].fullname || 'Teacher Name'}</h2>
                  <p className="text-xs sm:text-sm text-gray-500">
                    {teachers[post.teacher_id].city}, {teachers[post.teacher_id].country}
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-start space-y-2">
                <div className="text-xs sm:text-sm text-gray-500">
                  {post.created_at ? new Date(post.created_at).toLocaleDateString() : 'Date not available'}
                </div>
                <div className={`${post.status?.toLowerCase() === 'active' ? 'bg-green-600' : 'bg-red-600'} text-white text-xs sm:text-sm font-medium rounded-full px-4 py-1 shadow-md`}>
                  {post.status || 'Inactive'}
                </div>
              </div>
            </div>
          )} */}

          <div className="flex items-start justify-between">
            <h2 className="text-sm sm:text-lg font-bold">{post.course_title || 'Course Title'}</h2>
          </div>

          <p className="text-gray-700 text-xs sm:text-sm mt-2">
            {showFullDescription ? post.description : `${post.description?.slice(0, 100)}...`}
            {post.description?.length > 100 && (
              <button onClick={toggleDescription} className="text-blue-500 text-xs sm:text-sm">
                {showFullDescription ? ' See Less' : ' See More'}
              </button>
            )}
          </p>

          <div className="mt-4">
            <img src={post.poster_image ? `${baseUrl}/uploads/${post.poster_image}` : '/default-course.png'} alt="Course Banner" className="rounded-lg w-full" />
          </div>

          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div className="flex items-center space-x-2">
              <FaLanguage size={16} />
              <p className="font-bold text-xs sm:text-sm">Language:</p>
              <p className="text-xs sm:text-sm">{post.language || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <AiOutlineFileText size={16} />
              <p className="font-bold text-xs sm:text-sm">Subject:</p>
              <p className="text-xs sm:text-sm">{post.subject || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <BiUser size={16} />
              <p className="font-bold text-xs sm:text-sm">Gender:</p>
              <p className="text-xs sm:text-sm">{post.gender || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <FaCalendarAlt size={16} />
              <p className="font-bold text-xs sm:text-sm">Course Duration:</p>
              <p className="text-xs sm:text-sm">{post.course_duration || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <FaClock size={16} />
              <p className="font-bold text-xs sm:text-sm">Class Duration:</p>
              <p className="text-xs sm:text-sm">{post.class_duration || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <FaClock size={16} />
              <p className="font-bold text-xs sm:text-sm">Class Timing:</p>
              <p className="text-xs sm:text-sm">{post.class_timing || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <FaChalkboardTeacher size={16} />
              <p className="font-bold text-xs sm:text-sm">Total Classes:</p>
              <p className="text-xs sm:text-sm">{post.total_classes || 'Not specified'}</p>
            </div>
            <div className="flex items-center space-x-2">
              <FaDollarSign size={16} />
              <p className="font-bold text-xs sm:text-sm">Fee:</p>
              <p className="text-xs sm:text-sm">{post.fee ? `$${post.fee}` : 'Not specified'}</p>
            </div>
          </div>

          <div className="mt-4 flex flex-col sm:flex-row justify-around items-center border-t pt-2 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-2">
              <FaRegThumbsUp size={16} className="text-blue-500" />
              <p className="font-bold text-xs sm:text-sm">{likes || '0'}</p>
              <button className="text-blue-500 text-xs sm:text-sm" onClick={() => handleLikeCourse(post)}>
                Like
              </button>
            </div>

            <div className="flex items-center space-x-1 sm:space-x-2">
              <FaUserFriends size={14} className="text-blue-500" />
              <button className="font-bold text-xs sm:text-sm text-blue-500" onClick={handleOpenJoinRequestPopup}>
                Join Request
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
