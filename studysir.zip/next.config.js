// next.config.js
module.exports = {
    images: {
      domains: ['localhost'],
    },
  };
  