import React from "react";
 
import AdminList from "./AdminList";

const Page = () => {
  return (
    <div>
      <AdminList/>
    </div>
  );
};

export default Page;
