'use client';
import { useState, useEffect } from 'react';

export default function CourseTeacherId() {
  const [courses, setCourses] = useState([]); // State to hold courses data
  const [loading, setLoading] = useState(true); // State for loading indicator
  const [error, setError] = useState(''); // State to store any errors
  const [filteredCourses, setFilteredCourses] = useState([]); // To store filtered courses based on teacher ID
  const [teacher, setTeacher] = useState(null); // State to hold teacher information

  // Get base URL from environment variables
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        // Get teacher ID from localStorage
        const user = JSON.parse(localStorage.getItem('user'));
        if (!user || !user.id) {
          throw new Error('Teacher ID not found');
        }
        const teacherId = user.id.toString();  // Assuming teacher ID is stored in localStorage

        console.log('Fetching courses for teacher_id:', teacherId); // Debugging log

        // Fetch all courses from the API
        const coursesResponse = await fetch(`${baseUrl}/course_fetch_by_teacherID.php`, {
          method: 'GET',
          
        });
        

        if (!coursesResponse.ok) {
          throw new Error(`HTTP error! status: ${coursesResponse.status}`);
        }

        const coursesData = await coursesResponse.json();
        console.log('Fetched Courses Data:', coursesData); // Debugging log

        if (coursesData.length > 0) {
          // Filter courses based on the teacher ID
          const teacherCourses = coursesData.filter(course => course.teacher_id === teacherId);
          setFilteredCourses(teacherCourses);

          // Fetch teacher info based on teacher_id
          const teacherResponse = await fetch(`${baseUrl}/teacher_name_api.php?id=${teacherId}`, {
            method: 'GET',
          });

          if (!teacherResponse.ok) {
            throw new Error(`HTTP error! status: ${teacherResponse.status}`);
          }

          const teacherData = await teacherResponse.json();
          console.log('Fetched Teacher Data:', teacherData);

          setTeacher(teacherData); // Set teacher data in state
        } else {
          setError('No courses available.');
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Error connecting to the server.');
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, [baseUrl]);

  // If data is loading
  if (loading) {
    return <div>Loading...</div>;
  }

  // If there is an error
  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="grid grid-cols-1 w-[600px] gap-8">
      {/* Display Teacher Information */}
      {teacher && (
        <div className="mb-8 p-4 bg-white shadow-lg rounded-lg">
          <div className="flex items-center">
            <img
              src={teacher.image ? `${baseUrl}/uploads/${teacher.image}` : '/default-profile.png'}
              alt={teacher.fullname || 'Profile Picture'}
              width={100}
              height={100}
              className="rounded-full object-cover"
              style={{ width: '100px', height: '100px' }}
            />
            <div className="ml-4">
              <h2 className="text-xl font-bold">{teacher.fullname || 'Teacher Name'}</h2>
              <p className="text-gray-500">{teacher.address || 'Address not provided'}</p>
              <p className="text-gray-500">{teacher.city}, {teacher.country}</p>
            </div>
          </div>
        </div>
      )}

      {/* Display Filtered Courses */}
      {filteredCourses.length > 0 ? (
        filteredCourses.map((course) => (
          <div key={course.course_id} className="bg-white border rounded-lg shadow-lg p-4 my-8">
            <div className="flex items-start justify-between">
              <div className="flex items-center">
                <img
                  src={teacher?.image ? `${baseUrl}/uploads/${teacher.image}` : '/default-profile.png'}
                  alt={teacher?.fullname || 'Profile Picture'}
                  width={50}
                  height={50}
                  className="rounded-full"
                />
                <div className="ml-4">
                  <h2 className="text-lg font-bold">{teacher?.fullname || 'Teacher Name'}</h2>
                  <p className="text-gray-500">{teacher?.city}, {teacher?.country || 'Location not provided'}</p>
                </div>
              </div>
              <div>
                <span className="text-sm text-gray-400">{course.created_at || 'Date not available'}</span>
                <div
                  className={`${
                    course.status && course.status.toLowerCase() === 'active'
                      ? 'bg-green-500'
                      : 'bg-red-500'
                  } text-white text-sm rounded-full px-4 py-1 mt-1`}
                >
                  {course.status || 'Inactive'}
                </div>
              </div>
            </div>

            <h3 className="mt-4 text-xl font-bold">{course.course_title || 'Course Title'}</h3>

            <p className="text-gray-700 mt-2">
              {course.description || 'No description available.'} <span className="text-blue-500">See More</span>
            </p>

            <div className="mt-4">
              <img
                src={course.poster_image ? `${baseUrl}/uploads/${course.poster_image}` : '/default-course.png'}
                alt="Course Banner"
                width={600}
                height={400}
                className="rounded-lg"
              />
            </div>

            <div className="mt-4 grid grid-cols-6 gap-4 items-center">
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/language.png" alt="Language Icon" width={30} height={30} />
                <p className="font-bold">Language:</p>
                <p>{course.language || 'Not specified'}</p>
              </div>
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/subject1.png" alt="Subject Icon" width={20} height={20} />
                <p className="font-bold">Subject:</p>
                <p>{course.subject || 'Not specified'}</p>
              </div>
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/calander.png" alt="Duration Icon" width={20} height={20} />
                <p className="font-bold">Course Duration:</p>
                <p>{course.course_duration || 'Not specified'}</p>
              </div>
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/clock1.png" alt="Timing Icon" width={20} height={20} />
                <p className="font-bold">Class Timing:</p>
                <p>{course.class_timing || 'Not specified'}</p>
              </div>
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/totalclass1.png" alt="Total Classes Icon" width={20} height={20} />
                <p className="font-bold">Total Classes:</p>
                <p>{course.total_classes || 'Not specified'}</p>
              </div>
              <div className="col-span-6 flex items-center space-x-2">
                <img src="/feeWallet.png" alt="Fee Icon" width={20} height={20} />
                <p className="font-bold">Fee:</p>
                <p>{course.fee ? `$${course.fee}` : 'Not specified'}</p>
              </div>
            </div>
          </div>
        ))
      ) : (
        <p>No courses available for this teacher.</p>
      )}
    </div>
  );
}
