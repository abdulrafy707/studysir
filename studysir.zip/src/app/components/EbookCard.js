'use client';
import { useEffect, useState } from 'react';

export default function EbookCard() {
  const [ebooks, setEbooks] = useState([]); // State to hold fetched ebooks
  const [loading, setLoading] = useState(true); // State for loading status
  const [error, setError] = useState(''); // State for error handling

  // Get base URL from environment variables
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    // Function to fetch all ebooks from the API
    const fetchEbooks = async () => {
      try {
        // Log the API request URL
        console.log(`Fetching from: ${baseUrl}/ebook_api.php`);

        // Fetch all ebook records from the API
        const response = await fetch(`${baseUrl}/ebook_api.php`, {
          method: 'GET', // Specify GET method
        });

        // Check if the response is successful
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Parse the response as JSON
        const data = await response.json();
        console.log("Parsed Data:", data); // Log the parsed data

        if (Array.isArray(data) && data.length > 0) {
          setEbooks(data); // Store fetched ebooks in the state
        } else {
          setError('No ebooks available');
        }
      } catch (err) {
        console.error('Error fetching ebook posts:', err);
        setError('Error connecting to server or invalid JSON.');
      } finally {
        setLoading(false); // Stop loading after fetch is complete
      }
    };

    fetchEbooks();
  }, [baseUrl]);

  useEffect(() => {
    console.log("Ebooks State:", ebooks); // Log the ebooks state whenever it changes
  }, [ebooks]);

  // Show loading state
  if (loading) {
    return <div>Loading...</div>;
  }

  // Show error state if there is an error
  if (error) {
    return <div>{error}</div>;
  }

  // Render fetched ebooks
  return (
    <div>
      {ebooks.map((ebook) => (
        <div key={ebook.id} className="bg-white border rounded-lg shadow-lg p-4 w-[600px] my-8">
          <div className="flex justify-between">
            {/* Left: Ebook Image and Price */}
            <div className="flex items-start">
              <div>
                <img
                  src={`${baseUrl}/uploads/${ebook.ebook_image_url}`} // Use the image URL from the API with baseUrl
                  alt={ebook.ebook_title || 'Ebook Image'}
                  width={100}
                  height={150}
                  className="rounded-lg"
                />
                <p className="mt-2 text-gray-600 font-bold text-lg">Rs {ebook.price || 'N/A'}</p>
              </div>
            </div>

            {/* Middle: Ebook Information */}
            <div className="flex-1 ml-4">
              <h2 className="text-xl font-bold">{ebook.ebook_title || 'Ebook Title'}</h2>
              <p className="text-gray-500 text-sm">Written by {ebook.author_name || 'Author'}</p>

              <p className="text-gray-700 mt-2">
                {ebook.description || 'No description available.'}{' '}
                <span className="text-blue-500">See More</span>
              </p>

              <p className="mt-2 text-black font-bold">
                Seller: <span className="text-gray-600">{ebook.seller_name || 'Seller Name'}</span>
              </p>
            </div>

            {/* Right: Rating */}
            <div className="flex flex-col items-end">
              <div className="flex items-center">
                <div className="flex space-x-1">
                  {[...Array(5)].map((_, index) => (
                    <img
                      key={index}
                      src={index < Math.floor(ebook.rating || 0) ? '/star.png' : '/star-empty.png'}
                      alt="Star Rating"
                      width={20}
                      height={20}
                    />
                  ))}
                </div>
                <p className="ml-2 text-black font-bold">{ebook.rating || '0.0'}</p>
              </div>
            </div>
          </div>

          {/* Interaction Section */}
          <div className="mt-4 flex justify-between items-center border-t pt-2">
            {/* Like, Review, Share, and Download Buttons */}
            <div className="flex space-x-6">
              <button className="flex items-center text-gray-500 hover:text-blue-500">
                <img
                  src="/like.png"
                  alt="Like Icon"
                  width={20}
                  height={20}
                />
                <span className="ml-2">{ebook.likes || 0}</span>
              </button>

              <button className="flex items-center text-gray-500 hover:text-blue-500">
                <img
                  src="/review1.png"
                  alt="Review Icon"
                  width={20}
                  height={20}
                />
                <span className="ml-2">{ebook.reviews || 0}</span>
              </button>

              <button className="flex items-center text-gray-500 hover:text-blue-500">
                <img
                  src="/share.png"
                  alt="Share Icon"
                  width={20}
                  height={20}
                />
                <span className="ml-2">{ebook.shares || 0}</span>
              </button>
            </div>

            <button className="flex items-center text-gray-500 hover:text-blue-500">
              <img
                src="/download.png"
                alt="Download Icon"
                width={20}
                height={20}
              />
              <span className="ml-2">{ebook.downloads || 'Download'}</span>
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
