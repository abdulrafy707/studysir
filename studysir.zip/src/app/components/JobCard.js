'use client';
import { useEffect, useState } from 'react';
import { FaLanguage, FaChalkboardTeacher, FaMale, FaRegClock, FaWallet } from 'react-icons/fa';
import { AiOutlineLike } from 'react-icons/ai';
import { BsFillChatDotsFill, BsThreeDots } from 'react-icons/bs';
import { MdLocationOn } from 'react-icons/md';
import { BiShare } from 'react-icons/bi';

export default function JobCard() {
  const [posts, setPosts] = useState([]);
  const [fetchError, setFetchError] = useState(null);
  const [dropdownOpen, setDropdownOpen] = useState(null);
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const fetchPostsFromApi = async () => {
      try {
        const response = await fetch(`${baseUrl}/studentpost_api.php`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setPosts(data);
        } else {
          throw new Error('Data fetched is not an array.');
        }
      } catch (error) {
        setFetchError(error.message);
      }
    };

    fetchPostsFromApi();
  }, [baseUrl]);

  const handleSavePost = async (post) => {
    const userData = JSON.parse(localStorage.getItem('user'));

    if (!userData || !userData.id) {
      console.error('User not logged in');
      return;
    }

    const postData = {
      user_id: userData.id,
      post_id: post.post_id,
      post_type: 'studentpost', // Update this for 'teacherpost' or 'course' as needed
    };

    try {
      const response = await fetch(`${baseUrl}/save_post_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });

      const result = await response.json();
      if (result.success) {
        alert('Post saved successfully!');
      } else {
        alert(`Error saving post: ${result.error}`);
      }
    } catch (error) {
      console.error('Error saving post:', error);
    }
  };

  const toggleDropdown = (index) => {
    setDropdownOpen(dropdownOpen === index ? null : index);
  };

  if (fetchError) {
    return <div>Error: {fetchError}</div>;
  }

  if (!Array.isArray(posts) || posts.length === 0) {
    return <div>No posts available.</div>;
  }

  return (
    <div className="space-y-4">
      {posts.map((post, index) => (
        <div key={index} className="bg-white border rounded-lg shadow p-4 w-[600px] my-8 relative">
          {/* Header with student profile, name, and location */}
          <div className="flex items-start justify-between">
            <div className="flex items-center">
              <img
                src={post.profile_image ? `${baseUrl}/uploads/${post.profile_image}` : '/default-profile.png'}
                alt="Profile Picture"
                width={50}
                height={50}
                className="rounded-full"
              />
              <div className="ml-4">
                <h2 className="text-lg font-bold">{post.name || 'Student'}</h2>
                <p className="text-gray-500 flex items-center">
                  <MdLocationOn className="mr-1" />
                  {post.location || 'Location not provided'}
                </p>
              </div>
            </div>
            <div className="relative">
              <span className="text-sm text-gray-400">{post.posted_time || 'Posted time not available'}</span>
              <div
                className={`${
                  post.status && post.status.toLowerCase() === 'active' ? 'bg-green-500' : 'bg-red-500'
                } text-white text-sm rounded-full px-4 py-1 mt-1`}
              >
                {post.status || 'Inactive'}
              </div>
              {/* Three Dots Menu */}
              <BsThreeDots
                className="cursor-pointer text-gray-600 hover:text-gray-800 ml-2"
                onClick={() => toggleDropdown(index)}
              />
              {dropdownOpen === index && (
                <div className="absolute right-0 top-8 bg-white shadow-lg rounded-lg z-10">
                  <ul className="py-2">
                    <li
                      className="px-4 py-2 text-gray-700 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleSavePost(post)}
                    >
                      Save Post
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Job Title and Description */}
          <h3 className="mt-4 text-xl font-bold">{post.job_title || 'Job Title not available'}</h3>
          <p className="text-gray-700 mt-2">
            {post.job_description || 'Job description not provided'} <span className="text-blue-500">See More</span>
          </p>

          {/* Job details with icons */}
          <div className="mt-4 space-y-4">
            {/* Languages */}
            <div className="flex items-center space-x-2">
              <FaLanguage className="text-gray-700" />
              <p className="font-bold">Languages:</p>
              <p>{Array.isArray(post.languages) && post.languages.length > 0 ? post.languages.join(', ') : 'Not specified'}</p>
            </div>

            {/* Subjects */}
            <div className="flex items-center space-x-2">
              <FaChalkboardTeacher className="text-gray-700" />
              <p className="font-bold">Subjects:</p>
              <p>{Array.isArray(post.subjects) && post.subjects.length > 0 ? post.subjects.join(', ') : 'Not specified'}</p>
            </div>

            {/* Gender */}
            <div className="flex items-center space-x-2">
              <FaMale className="text-gray-700" />
              <p className="font-bold">Required Gender:</p>
              <p>{post.required_gender || 'Not specified'}</p>
            </div>

            {/* Time Availability */}
            <div className="flex items-center space-x-2">
              <FaRegClock className="text-gray-700" />
              <p className="font-bold">Time Availability:</p>
              <p>{post.time_availability || 'Not specified'}</p>
            </div>

            {/* Fee Budget */}
            <div className="flex items-center space-x-2">
              <FaWallet className="text-gray-700" />
              <p className="font-bold">Fee Budget:</p>
              <p>{post.fee_budget ? `${post.fee_budget}$` : 'Not specified'}</p>
            </div>
          </div>

          {/* Action Buttons: Like, Share, and Live Chat */}
          <hr className="mt-4" />
          <div className="mt-4 flex justify-between items-center">
            <div className="flex space-x-6">
              <button className="flex items-center text-gray-500 hover:text-blue-500">
                <AiOutlineLike className="mr-1" />
                <span>Like</span>
              </button>
              <button className="flex items-center text-gray-500 hover:text-blue-500">
                <BiShare className="mr-1" />
                <span>Share</span>
              </button>
            </div>
            <button className="flex items-center text-gray-500 hover:text-blue-500">
              <BsFillChatDotsFill className="mr-1" />
              <span>Live Chat</span>
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
