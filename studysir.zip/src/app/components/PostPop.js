'use client';
import { useState, useEffect } from 'react';

const PostPopup = ({ onClose }) => {
    const [formData, setFormData] = useState({
        student_id: '',
        job_title: '',
        job_description: '',
        required_gender: '',
        time_availability: '',
        fee_budget: '',
        languages: '',  // Comma-separated string for languages
        subjects: '',   // Comma-separated string for subjects
    });

    // Fetch the student ID from local storage when the component mounts
    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData && userData.id && userData.role === 'student') {
            setFormData((prev) => ({
                ...prev,
                student_id: userData.id, // Pre-fill student_id from user data
            }));
        }
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async () => {
        try {
            // Prepare data for submission with languages and subjects as arrays
            const updatedFormData = {
                ...formData,
                languages: formData.languages.split(',').map(item => item.trim()),  // Convert comma-separated to array
                subjects: formData.subjects.split(',').map(item => item.trim()),    // Convert comma-separated to array
            };

            const response = await fetch('http://localhost/academy/studentpost_api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updatedFormData),
            });

            const textResponse = await response.text(); // Get raw response
            console.log('Raw response from server:', textResponse);
            const data = JSON.parse(textResponse);  // Try to parse it as JSON

            if (data.success) {
                alert('Post added successfully!');
                onClose();
            } else {
                alert('Error: ' + data.error);
            }
        } catch (error) {
            console.error('Error posting:', error);
        }
    };

    return (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex justify-center items-center">
            <div className="bg-white rounded-lg shadow-lg p-6 w-[500px]">
                <h2 className="text-2xl font-bold mb-4">Post a Tuition Ad</h2>

                {/* Form Fields */}
                <input
                    type="text"
                    name="student_id"
                    placeholder="Student ID"
                    value={formData.student_id}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                    disabled
                />
                <input
                    type="text"
                    name="job_title"
                    placeholder="Job Title"
                    value={formData.job_title}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />
                <textarea
                    name="job_description"
                    placeholder="Job Description"
                    value={formData.job_description}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />
                <input
                    type="text"
                    name="required_gender"
                    placeholder="Required Gender"
                    value={formData.required_gender}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />
                <input
                    type="text"
                    name="time_availability"
                    placeholder="Time Availability"
                    value={formData.time_availability}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />
                <input
                    type="text"
                    name="fee_budget"
                    placeholder="Fee Budget"
                    value={formData.fee_budget}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />

                {/* Subjects Field */}
                <input
                    type="text"
                    name="subjects"
                    placeholder="Subjects (comma-separated)"
                    value={formData.subjects}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />

                {/* Languages Field */}
                <input
                    type="text"
                    name="languages"
                    placeholder="Languages (comma-separated)"
                    value={formData.languages}
                    onChange={handleInputChange}
                    className="w-full mb-4 p-2 border rounded"
                />

                {/* Buttons */}
                <div className="flex justify-between">
                    <button
                        onClick={onClose}
                        className="bg-red-500 text-white px-4 py-2 rounded"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSubmit}
                        className="bg-blue-500 text-white px-4 py-2 rounded"
                    >
                        Post
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PostPopup;
