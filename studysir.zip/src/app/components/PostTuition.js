'use client';
import { useState, useEffect } from 'react';
import Image from 'next/image';
import PostPopup from './PostPop'; // Popup component for students

const PostTuitionBox = () => {
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [role, setRole] = useState(null); // Store user role
    const [posts, setPosts] = useState([]); // Store fetched posts
    const baseUrl = 'http://localhost/academy'; // Update with your correct API base URL

    useEffect(() => {
        // Get the user info from localStorage
        const user = JSON.parse(localStorage.getItem('user'));

        if (user && user.role === 'student') {
            setRole(user.role); // Set the role from localStorage if it's a student
        }

        // Fetch posts from the API on component mount
        const fetchPosts = async () => {
            try {
                const response = await fetch(`${baseUrl}/studentpost_api.php`, {
                    method: 'GET',
                });
                const data = await response.json();
                setPosts(data); // Store the fetched posts in state
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };

        fetchPosts(); // Call the function to fetch posts
    }, []);

    const handleOpenPopup = () => {
        setIsPopupOpen(true);
    };

    const handleClosePopup = () => {
        setIsPopupOpen(false);
    };

    const handlePostSubmit = async (postData) => {
        try {
            const response = await fetch(`${baseUrl}/studentpost_api.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(postData), // Send the post data from the popup
            });
            const data = await response.json();

            if (data.success) {
                setPosts((prevPosts) => [data, ...prevPosts]); // Update the posts list with the new post
                handleClosePopup(); // Close the popup after successful submission
            } else {
                console.error('Error posting tuition:', data.error);
            }
        } catch (error) {
            console.error('Error posting tuition:', error);
        }
    };

    return (
        <div className="relative">
            <div className="flex items-center shadow-lg justify-between w-[700px] h-[100px] p-4 border-2 hover:border-blue-200 rounded-lg">
                {/* Profile Image */}
                <div className="flex-shrink-0">
                    <Image
                        src="/man.png" // Replace with the actual image path
                        alt="Warren Buffet"
                        width={60}
                        height={60}
                        className="rounded-full"
                    />
                </div>

                {/* Message Box */}
                <div className="flex-grow ml-4">
                    <div className="bg-gray-100 px-4 py-2 rounded-full cursor-pointer" onClick={handleOpenPopup}>
                        <p className="text-gray-700">Hi! Warren, Post Your tuition here</p>
                    </div>
                </div>
            </div>

            {/* Render the posts below the message box */}
            <div className="mt-4">
                {posts.length > 0 ? (
                    posts.map((post) => (
                        <div key={post.post_id} className="bg-white border rounded-lg shadow p-4 my-4">
                            <div className="flex items-start justify-between">
                                <div className="flex items-center">
                                    <img
                                        src={post.student_profile_image ? `${baseUrl}/uploads/${post.student_profile_image}` : '/default-profile.png'}
                                        alt={post.student_name}
                                        width={50}
                                        height={50}
                                        className="rounded-full"
                                    />
                                    <div className="ml-4">
                                        <h2 className="text-lg font-bold">{post.student_name}</h2>
                                        <p className="text-gray-500">{post.student_location}</p>
                                    </div>
                                </div>
                                <div>
                                    <span className="text-sm text-gray-400">{post.posted_time}</span>
                                </div>
                            </div>
                            <h3 className="mt-4 text-xl font-bold">{post.job_title}</h3>
                            <p className="mt-2 text-gray-700">{post.job_description}</p>
                            <div className="mt-4">
                                <p>Required Gender: {post.required_gender}</p>
                                <p>Time Availability: {post.time_availability}</p>
                                <p>Fee Budget: {post.fee_budget ? `$${post.fee_budget}` : 'Not specified'}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <p>No tuition posts available at the moment.</p>
                )}
            </div>

            {/* Conditionally render the popup only if the role is 'student' */}
            {isPopupOpen && role === 'student' && <PostPopup onClose={handleClosePopup} onSubmit={handlePostSubmit} />}
        </div>
    );
};

export default PostTuitionBox;
