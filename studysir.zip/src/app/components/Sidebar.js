'use client';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

const Sidebar = () => {
    const [userRole, setUserRole] = useState(null); // State to track the user's role
    const router = useRouter();

    // Function to handle logout
    const handleLogout = () => {
        localStorage.removeItem('user'); // Clear user data
        router.push('/'); // Redirect to the homepage or login
    };

    // Function to navigate to courses
    const gotoCourse = () => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData && userData.id) {
            router.push(`/student/courses`); // Navigate to courses
        } else {
            console.error('User not found');
        }
    };

    // Function to navigate to ebooks
    const gotoEbook = () => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData && userData.id) {
            router.push(`/student/ebooks`); // Navigate to ebooks
        } else {
            console.error('User not found');
        }
    };

    // Effect to check the user's role from localStorage
    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData && userData.role === 'student') {
            setUserRole('student'); // Set the user role if it's 'student'
        }
    }, []); // Runs only once when the component mounts

    // Don't render the sidebar if the user is not a student
    if (userRole !== 'student') {
        return null;
    }

    return (
        <div className="bg-gray-100 w-64 fixed h-screen p-5">
            <ul className="space-y-6">
                {/* User Profile */}
                <li className="flex items-center space-x-3">
                    <Image
                        src="/man.png" // Replace with actual image path
                        alt="Warren Buffet"
                        width={40}
                        height={40}
                        className="rounded-full"
                    />
                    <span className="font-bold">Warren Buffet</span>
                </li>

                {/* Menu Items */}
                <li className="flex items-center space-x-3 cursor-pointer" onClick={gotoCourse}>
                    <Image src="/course.png" alt="Courses" width={24} height={24} />
                    <span className="font-semibold">Courses</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={gotoEbook}>
                    <Image src="/digital.png" alt="Digital Store" width={24} height={24} />
                    <span className="font-semibold">Digital Store</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/money_wallet.png" alt="Money Wallet" width={24} height={24} />
                    <span className="font-semibold">Money Wallet</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/managecalander.png" alt="Manage Calendar" width={24} height={24} />
                    <span className="font-semibold">Manage Calendar</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/savedposts.png" alt="Saved Posts" width={24} height={24} />
                    <span className="font-semibold">Saved Posts</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/programs.png" alt="Affiliate Program" width={24} height={24} />
                    <span className="font-semibold">Affiliate Program</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/setting.png" alt="Settings" width={24} height={24} />
                    <span className="font-semibold">Settings</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={handleLogout}>
                    <Image src="/logout.png" alt="Logout" width={24} height={24} />
                    <span className="font-semibold">Logout</span>
                </li>
            </ul>
        </div>
    );
};

export default Sidebar;
