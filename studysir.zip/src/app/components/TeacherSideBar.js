'use client';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import BuyCoinsModal from './BuyCoinsModal'; // Import the new component for sending request

const TeacherSideBar = () => {
    const router = useRouter();
    const [isBuyCoinsOpen, setIsBuyCoinsOpen] = useState(false); // State to track the modal visibility
    const [user, setUser] = useState(null); // State to store user information

    // Use environment variable for the base URL
    const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData) {
            setUser(userData); // Set user data if available
        } else {
            console.error('User data not found.');
        }
    }, []);

    const handleLogout = () => {
        // Clear the user data from localStorage
        localStorage.removeItem('user');
        router.push('/');
    };

    const openBuyCoinsModal = () => {
        setIsBuyCoinsOpen(true); // Open the modal
    };

    const closeBuyCoinsModal = () => {
        setIsBuyCoinsOpen(false); // Close the modal
    };

    const goToCoursesPage = () => {
        if (user && user.id) {
            router.push(`/teacher/coursespage?teacher_id=${user.id}`); // Navigate to courses page with teacher_id
        } else {
            console.error('User data not found.');
        }
    };

    const goToEbookPage = () => {
        if (user && user.id) {
            router.push(`/teacher/ebooks?teacher_id=${user.id}`); // Navigate to ebook page with teacher_id
        } else {
            console.error('User data not found.');
        }
    };

    const goToCoinHistory = () => {
        if (user && user.id) {
            router.push(`/teacher/coin_history?teacher_id=${user.id}`); // Navigate to coin history page
        } else {
            console.error('User not found');
        }
    };

    return (
        <div className="bg-gray-100 w-64 h-screen p-5">
            <ul className="space-y-6">
                {/* User Profile */}
                <li className="flex items-center space-x-3">
                    {user?.profileImage ? (
                        <img
                            src={`${baseUrl}/uploads/${user.profileImage}`} // Construct full image URL from base URL and image name
                            alt={user.fullname || 'User Image'}
                            width={40}
                            height={40}
                            className="rounded-full object-cover"
                            onLoad={() => console.log(`Image loaded: ${baseUrl}/uploads/${user.profileImage}`)} // Console log the image URL when loaded
                        />
                    ) : (
                        <img
                            src="/default-profile.png" // Fallback if no image is available
                            alt="Default Image"
                            width={40}
                            height={40}
                            className="rounded-full"
                            onLoad={() => console.log('Default image loaded')}
                        />
                    )}
                    <span className="font-bold">{user?.fullname || 'User'}</span>
                </li>

                {/* Menu Items */}
                <li className="flex items-center space-x-3 cursor-pointer" onClick={goToCoursesPage}>
                    <Image src="/course.png" alt="Courses" width={24} height={24} />
                    <span className="font-semibold">Courses</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={goToEbookPage}>
                    <Image src="/digital.png" alt="Digital Products" width={24} height={24} />
                    <span className="font-semibold">Digital Products</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={openBuyCoinsModal}>
                    <Image src="/coins.png" alt="Buy Coins" width={24} height={24} />
                    <span className="font-semibold">Buy Coins</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={goToCoinHistory}>
                    <Image src="/coinhistory.png" alt="Coin History" width={24} height={24} />
                    <span className="font-semibold">Coins History</span>
                </li>
                {/* <li className="flex items-center space-x-3">
                    <Image src="/wallet.png" alt="Coins Wallet" width={24} height={24} />
                    <span className="font-semibold">Coins Wallet</span>
                </li> */}
                <li className="flex items-center space-x-3">
                    <Image src="/savedposts.png" alt="Saved Posts" width={24} height={24} />
                    <span className="font-semibold">Saved Posts</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/programs.png" alt="Affiliate Program" width={24} height={24} />
                    <span className="font-semibold">Affiliate Program</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/manage.png" alt="Manage Reviews" width={24} height={24} />
                    <span className="font-semibold">Manage Reviews</span>
                </li>
                <li className="flex items-center space-x-3">
                    <Image src="/setting.png" alt="Settings" width={24} height={24} />
                    <span className="font-semibold">Settings</span>
                </li>
                <li className="flex items-center space-x-3 cursor-pointer" onClick={handleLogout}>
                    <Image src="/logout.png" alt="Logout" width={24} height={24} />
                    <span className="font-semibold">Logout</span>
                </li>
            </ul>

            {/* Conditionally render the Buy Coins Modal */}
            {isBuyCoinsOpen && <BuyCoinsModal onClose={closeBuyCoinsModal} />}
        </div>
    );
};

export default TeacherSideBar;
