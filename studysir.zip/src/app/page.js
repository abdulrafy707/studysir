'use client'; // Ensure this is a client-side component

import { Provider } from 'react-redux';
import { store } from './store/store'; // Adjust this path as per your directory structure
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import PostTuition from "./components/PostTuition";
import JobCard from "./components/JobCard";
import CourseCard from "./components/CourseCard";
import EbookCard from "./components/EbookCard";
import TeacherProfileCard from "./components/TeacherProfileCard";
import SignInPage from "./components/login";
import Banner from './components/Banner';

export default function Home() {
  return (
    <Provider store={store}>
      {/* Header at the top */}
      <Header />

      {/* Flexbox layout to split the sidebar and content */}
      <div className="flex flex-col items-center justify-center">
        {/* Main content section */}
        <div className="w-full flex flex-col items-center justify-center space-y-4 mt-4">
          {/* Make the Banner full width */}
          <div className="w-full">
            <Banner />
          </div>
          {/* Center other components with a max width */}
          <div className="w-full max-w-2xl">
            <JobCard className="items-start justify-start" />
            <CourseCard />
            <EbookCard />
            <TeacherProfileCard />
            {/* <SignI nPage /> */}
          </div>
        </div>
      </div>
    </Provider>
  );
}
