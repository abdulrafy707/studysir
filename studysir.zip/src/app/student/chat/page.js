'use client';
import { useState, useEffect } from 'react';
import Image from 'next/image';

export default function ChatInterface({ studentId, teacherId }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const [teacherDetails, setTeacherDetails] = useState(null); // Store teacher details

  // Fetch teacher details when component loads
  useEffect(() => {
    const fetchTeacherDetails = async () => {
      try {
        const response = await fetch(`http://localhost/academy/teacher_details_api.php?teacher_id=${2}`);
        const data = await response.json();
        if (data.success) {
          setTeacherDetails(data.teacher); // Set the teacher details
        } else {
          setError('Failed to load teacher details');
        }
      } catch (error) {
        console.error('Error fetching teacher details:', error);
        setError('Error connecting to the server');
      }
    };

    fetchTeacherDetails();
  }, [teacherId]);

  // Fetch chat messages when component loads
  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await fetch(`http://localhost/academy/fetch_msg_api.php?student_id=${studentId}&teacher_id=${teacherId}`);
        const data = await response.json();
        if (data.success) {
          setMessages(data.messages);
        } else {
          setError('Failed to load messages');
        }
      } catch (error) {
        console.error('Error fetching messages:', error);
        setError('Error connecting to the server');
      }
    };

    fetchMessages();
  }, [studentId, teacherId]);

  const handleSendMessage = async () => {
    if (newMessage.trim() === '') return;
  
    const messagePayload = {
      sender_id: 2,  // Check if studentId is valid
      receiver_id: 2,  // Check if teacherId is valid
      message: newMessage,
    };
  
    // Log the payload before sending
    console.log("Sending message:", messagePayload);
  
    try {
      const response = await fetch('http://localhost/academy/send_api.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messagePayload),
      });
  
      const data = await response.json();
  
      if (data.success) {
        // Add the new message to the chat view
        const newMsg = {
          sender: 'student',  // Assuming this is the student sending the message
          text: newMessage,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages([...messages, newMsg]);
        setNewMessage('');
      } else {
        console.error('Failed to send message:', data.error);
        setError('Failed to send message.');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setError('Error connecting to the server.');
    }
  };
  

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center items-center">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden w-[400px] md:w-[500px]">
        {/* Header */}
        <div className="bg-blue-600 text-white px-4 py-2 flex items-center justify-between">
          <div className="flex items-center">
            {/* Display teacher's image and name if available */}
            <Image
              src={teacherDetails?.image || '/default-profile.png'} // Fallback to default if no image is available
              alt="Teacher Profile"
              width={40}
              height={40}
              className="rounded-full"
            />
            <div className="ml-3">
              <p className="font-bold">{teacherDetails?.fullname || 'Unknown Teacher'}</p>
              <p className="text-xs">Last seen today at 2:46 AM</p>
            </div>
          </div>
        </div>

        {/* Chat Body */}
        <div className="p-4 space-y-4 max-h-[500px] overflow-y-auto">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.sender === 'student' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`p-2 rounded-lg max-w-[75%] ${message.sender === 'student' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-black'}`}>
                <p>{message.text}</p>
                <p className="text-xs mt-1">
                  {message.time} {message.date && <span>{message.date}</span>}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="px-4 py-2 bg-gray-100 border-t">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Write your message"
              className="flex-grow px-4 py-2 rounded-full border"
            />
            <button
              onClick={handleSendMessage}
              className="bg-blue-500 text-white px-4 py-2 rounded-full"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M2.94 15.61l2.804-1.001A8.146 8.146 0 005.5 11c0-.774.106-1.523.308-2.224L2.94 7.775a.5.5 0 00-.94.218v6.797c0 .373.421.605.76.42zM10.897 3.071a8.004 8.004 0 014.868 3.246l-3.32 1.187a.5.5 0 00-.25.253L9.5 10l3.322 1.817a.5.5 0 00.25.253l3.32 1.187a8.004 8.004 0 01-4.868 3.246A7.999 7.999 0 013.224 4.897a7.998 7.998 0 017.673-1.826z" />
              </svg>
            </button>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex justify-between px-4 py-2 bg-white border-t">
          <button className="bg-blue-500 text-white px-4 py-2 rounded-lg">Hire Teacher</button>
          <button className="bg-red-500 text-white px-4 py-2 rounded-lg">Reject</button>
          <button className="bg-red-500 text-white px-4 py-2 rounded-lg">Block</button>
          <button className="bg-red-400 text-white px-4 py-2 rounded-lg">Report</button>
        </div>
      </div>
    </div>
  );
}
