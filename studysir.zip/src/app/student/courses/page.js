import CourseList from "@/app/components/CourseCard";


export default function Page() {
  return (
    <div className="container mx-auto p-8">
      {/* Render the EbookCard component */}
      
      <CourseList/>
    </div>
  );
}
