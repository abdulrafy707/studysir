import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import PostTuition from "../components/PostTuition";
import JobCard from "../components/JobCard";
import CourseCard from "../components/CourseCard";
import EbookCard from "../components/EbookCard";
import TeacherProfileCard from "../components/TeacherProfileCard";
// import SignInPage from "./components/login";

export default function Home() {
  return (
    <>
      {/* Header at the top */}
      {/* <Header /> */}

      {/* Flexbox layout to split the sidebar and content */}
      <div className="flex">
        {/* Sidebar on the left */}
        <div className="w-1/4">
          {/* <Sidebar /> */}
        </div>

        {/* Main content section */}
        <div className="w-3/4 flex flex-col items-start justify-start space-y-4 mt-4">
          {/* PostTuition at the top */}
          <div className="w-full">
            <PostTuition />
            <JobCard className="items-start justify-start" />
            <CourseCard/>
            <EbookCard/>
            <TeacherProfileCard/>
            
            
          </div>

          
        </div>
      </div>
    </>
  );
}
