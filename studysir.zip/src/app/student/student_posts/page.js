// import EbookCard from "@/app/components/EbookCard";

import JobCard from "@/app/components/JobCard";

export default function Page() {
  return (
    <div className="container mx-auto p-8">
      {/* Render the EbookCard component */}
      {/* <EbookCard /> */}
      <JobCard/>
    </div>
  );
}
