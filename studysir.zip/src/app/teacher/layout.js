import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import TeacherSideBar from "../components/TeacherSideBar";

export default function Layout({ children }) {
  return (
    <>
      {/* Header at the top */}
      <Header />

      {/* Flexbox layout to split the sidebar and content */}
      <div className="flex pt-16">
        {/* Sidebar on the left */}
        <div className="w-1/4">
          <TeacherSideBar/>
        </div>

        {/* Main content section */}
        <div className="w-3/4 p-6">
          {children} {/* Dynamic content from pages */}
        </div>
      </div>
    </>
  );
}
