'use client';
import { useState, useEffect } from 'react';
// Import icons from react-icons
import { FaLanguage, FaChalkboardTeacher, FaMale, FaRegClock, FaWallet, FaCalendarAlt, FaDollarSign, FaClock } from 'react-icons/fa';
import { AiOutlineLike } from 'react-icons/ai';
import { BsFillChatDotsFill } from 'react-icons/bs';
import { MdLocationOn } from 'react-icons/md';
import { BiShare } from 'react-icons/bi';

export default function SavedPosts() {
  const [savedPosts, setSavedPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  useEffect(() => {
    const fetchSavedPosts = async () => {
      const userData = JSON.parse(localStorage.getItem('user'));

      if (!userData || !userData.id) {
        setError('User not logged in.');
        return;
      }

      try {
        const response = await fetch(`${baseUrl}/get_saved_post_api.php?user_id=${userData.id}`, {
          method: 'GET',
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        if (Array.isArray(data)) {
          setSavedPosts(data);
        } else {
          throw new Error('Failed to fetch saved posts.');
        }
      } catch (err) {
        setError('Error fetching saved posts.');
      } finally {
        setLoading(false);
      }
    };

    fetchSavedPosts();
  }, [baseUrl]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-4">Saved Posts</h2>
      {savedPosts.length === 0 ? (
        <div>No saved posts available.</div>
      ) : (
        savedPosts.map((post) => (
          <div key={post.post_id} className="bg-white border rounded-lg shadow p-4 w-[600px] my-8">
            {/* Display full details based on post type */}
            {post.post_type === 'studentpost' && (
              <>
                <div className="flex items-start justify-between">
                  <div className="flex items-center">
                    <img
                      src={post.profile_image ? `${baseUrl}/uploads/${post.profile_image}` : '/default-profile.png'}
                      alt="Profile Picture"
                      width={50}
                      height={50}
                      className="rounded-full"
                    />
                    <div className="ml-4">
                      <h2 className="text-lg font-bold">{post.post_author || 'Student'}</h2>
                      <p className="text-gray-500 flex items-center">
                        <MdLocationOn className="mr-1" />
                        {post.location || 'Location not provided'}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm text-gray-400">{post.created_at}</span>
                </div>
                <h3 className="mt-4 text-xl font-bold">{post.post_title || 'Job Title not available'}</h3>
                <p className="text-gray-700 mt-2">{post.job_description || 'Job description not provided'}</p>
                <div className="mt-4 space-y-4">
                  <div className="flex items-center space-x-2">
                    <FaLanguage className="text-gray-700" />
                    <p className="font-bold">Languages:</p>
                    <p>{post.languages || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaChalkboardTeacher className="text-gray-700" />
                    <p className="font-bold">Subjects:</p>
                    <p>{post.subjects || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaMale className="text-gray-700" />
                    <p className="font-bold">Required Gender:</p>
                    <p>{post.required_gender || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaClock className="text-gray-700" />
                    <p className="font-bold">Time Availability:</p>
                    <p>{post.time_availability || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaWallet className="text-gray-700" />
                    <p className="font-bold">Fee Budget:</p>
                    <p>{post.fee_budget ? `${post.fee_budget}$` : 'Not specified'}</p>
                  </div>
                </div>
              </>
            )}

            {post.post_type === 'teacherpost' && (
              <>
                <h3 className="text-lg font-bold">Teacher Post</h3>
                <p className="text-gray-700">{post.post_description || 'No description available.'}</p>
                <p>Rating: {post.rating || 'Not available'}</p>
                <p>Fee Range: {post.fee_range || 'Not available'}</p>
              </>
            )}

            {post.post_type === 'course' && (
              <>
                <h3 className="text-xl font-bold">{post.post_title || 'Course Title not available'}</h3>
                <p className="text-gray-500">{post.post_description || 'No description available.'}</p>
                <div className="mt-4 space-y-4">
                  <div className="flex items-center space-x-2">
                    <FaLanguage className="text-gray-700" />
                    <p className="font-bold">Language:</p>
                    <p>{post.language || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaChalkboardTeacher className="text-gray-700" />
                    <p className="font-bold">Subject:</p>
                    <p>{post.subject || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaCalendarAlt className="text-gray-700" />
                    <p className="font-bold">Course Duration:</p>
                    <p>{post.course_duration || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaClock className="text-gray-700" />
                    <p className="font-bold">Class Timing:</p>
                    <p>{post.class_timing || 'Not specified'}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <FaDollarSign className="text-gray-700" />
                    <p className="font-bold">Fee:</p>
                    <p>{post.fee || 'Not specified'}</p>
                  </div>
                </div>
              </>
            )}

            {post.post_type === 'ebook' && (
              <>
                <h3 className="text-xl font-bold">{post.post_title || 'Ebook Title not available'}</h3>
                <p className="text-gray-500">Written by {post.author_name || 'Author not available'}</p>
                <p className="text-gray-700">{post.description || 'No description available.'}</p>
                <p>Price: {post.price || 'Not available'}</p>
              </>
            )}
          </div>
        ))
      )}
    </div>
  );
}
