'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function AuthPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const router = useRouter();

  const handleSignIn = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost/academy/login_api.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username,
          password,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Store user data and isAuthenticated status in localStorage
        localStorage.setItem('user', JSON.stringify({
          id: data.user.id,
          username: data.user.username,
          fullname: data.user.fullname,
          role: data.user.role,
          image: data.user.image,
          isAuthenticated: true,
        }));

        // Redirect to the appropriate page based on user role
        if (data.user.role === 'student') {
          router.push('/student');
        } else if (data.user.role === 'teacher') {
          router.push('/teacher');
        }
      } else {
        setErrorMessage(data.error || 'Login failed, please try again.');
      }
    } catch (error) {
      setErrorMessage('Error connecting to the server.');
    }
  };

  return (
    <div className="min-h-screen flex justify-center items-center bg-gray-100">
      <div className="hidden md:flex w-full max-w-4xl bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="w-1/2 flex items-center justify-center">
          <Image
            src="/signin.png"
            alt="Sign In Illustration"
            width={800}
            height={800}
            className="object-contain"
          />
        </div>

        <div className="w-1/2 p-8 flex flex-col justify-center">
          <h2 className="text-3xl font-bold text-blue-600 text-center mb-8">Sign in</h2>
          {errorMessage && <p className="text-red-500 mb-4">{errorMessage}</p>}

          <form onSubmit={handleSignIn}>
            <input
              type="text"
              placeholder="Username"
              className="border border-blue-500 w-full py-2 px-4 mb-4 rounded-md"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              className="border border-blue-500 w-full py-2 px-4 mb-2 rounded-md"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="submit"
              className="bg-blue-500 text-white w-full py-2 rounded-md hover:bg-blue-600 transition duration-200"
            >
              Sign in
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
