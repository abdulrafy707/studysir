'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function SignupStep1() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSignup = async () => {
    if (!email || !password || !role) {
      setError('Email, Password, and Role are required.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student_teacher_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          action: 'signup',
          email,
          password,
          role,
        }),
      });

      const data = await response.json();
      console.log('Response:', data);

      if (response.ok && data.success) {
        // Move to the second page (verification) with email and role as query params
        router.push(`/user/pages/signup2ndpage?email=${encodeURIComponent(email)}&role=${encodeURIComponent(role)}`);
      } else {
        setError(data.error || 'An error occurred.');
        console.error('Error from server:', data.error || 'Unknown error');
      }
    } catch (err) {
      setError('Error connecting to server.');
      console.error('Fetch error:', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-xl font-bold mb-4">Signup (Step 1)</h1>
      {error && <div className="text-red-500 mb-4">{error}</div>}
      <input
        type="email"
        placeholder="Enter email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <input
        type="password"
        placeholder="Enter password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <select
        value={role}
        onChange={(e) => setRole(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      >
        <option value="">Select Role</option>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
      <button
        onClick={handleSignup}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        {loading ? 'Submitting...' : 'Submit'}
      </button>
    </div>
  );
}
