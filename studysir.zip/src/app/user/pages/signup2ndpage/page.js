'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function SignupStep2() {
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState(''); // Capture the role
  const router = useRouter();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setEmail(params.get('email') || '');
    setRole(params.get('role') || ''); // Capture role from query params
  }, []);

  const handleVerify = async () => {
    if (!verificationCode) {
      setError('Verification code is required.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student_teacher_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          action: 'verify_code',
          email,
          verification_code: verificationCode,
        }),
      });

      const data = await response.json();
      console.log('Response:', data);

      if (response.ok && data.success) {
        // Move to the third page (personal details) with email and role as query params
        router.push(`/user/pages/signup3rdpage?email=${encodeURIComponent(email)}&role=${encodeURIComponent(role)}`);
      } else {
        setError(data.error || 'An error occurred.');
        console.error('Error from server:', data.error || 'Unknown error');
      }
    } catch (err) {
      setError('Error connecting to server.');
      console.error('Fetch error:', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-xl font-bold mb-4">Verify Email (Step 2)</h1>
      {error && <div className="text-red-500 mb-4">{error}</div>}
      <input
        type="text"
        placeholder="Enter verification code"
        value={verificationCode}
        onChange={(e) => setVerificationCode(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <button
        onClick={handleVerify}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        {loading ? 'Verifying...' : 'Verify'}
      </button>
    </div>
  );
}
