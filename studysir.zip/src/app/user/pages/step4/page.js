'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function SignupStep4() {
  const [qualification, setQualification] = useState('');
  const [university, setUniversity] = useState('');
  const [experience, setExperience] = useState('');
  const [languages, setLanguages] = useState('');
  const [subjects, setSubjects] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const router = useRouter();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setEmail(params.get('email') || '');
  }, []);

  const handleEducationalDetails = async () => {
    if (!qualification || !university || !experience || !languages || !subjects) {
      setError('All fields are required.');
      return;
    }

    if (isNaN(experience)) {
      setError('Experience must be numeric.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student_teacher_api.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          action: 'save_educational_details',  // Ensure the action is being sent properly
          email,
          qualification,
          university,
          experience,
          languages,
          subjects,
        }),
      });

      const data = await response.json();
      console.log('Response:', data);

      if (response.ok && data.success) {
        // Redirect to the login page after successfully saving educational details
        router.push(`/user/pages/login`);
      } else {
        setError(data.error || 'An error occurred.');
        console.error('Error from server:', data.error || 'Unknown error');
      }
    } catch (err) {
      setError('Error connecting to server.');
      console.error('Fetch error:', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-xl font-bold mb-4">Educational Details (Step 4)</h1>
      {error && <div className="text-red-500 mb-4">{error}</div>}
      <input
        type="text"
        placeholder="Enter your qualification"
        value={qualification}
        onChange={(e) => setQualification(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <input
        type="text"
        placeholder="Enter your university"
        value={university}
        onChange={(e) => setUniversity(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <input
        type="text"
        placeholder="Enter your experience in years"
        value={experience}
        onChange={(e) => setExperience(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <input
        type="text"
        placeholder="Enter the languages you speak (comma separated)"
        value={languages}
        onChange={(e) => setLanguages(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <input
        type="text"
        placeholder="Enter the subjects you teach (comma separated)"
        value={subjects}
        onChange={(e) => setSubjects(e.target.value)}
        className="border rounded mb-4 p-2 w-full"
      />
      <button
        onClick={handleEducationalDetails}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        {loading ? 'Submitting...' : 'Submit'}
      </button>
    </div>
  );
}
